/* ==================================================================
  USER MANAGEMENT : VALIDATION SCRIPT
==================================================================== */
function changepwd_validation1(input)
{ 

//console.log('validtion');
//console.log(input);
   var err = new Array(4);   
    var errcount=0;
    var innerhtml='';
    var divtop='<div ID="panelWarning" class="resultpanel"><span class="errLabel">';
    var divbottom='</span></div>';
    
    if(input.oldpwd.value == '') {
       err[0]="Please enter old password";
       input.oldpwd.focus();
    }
    else if(input.newpwd.value == '') {
     err[1]="Please enter new password";
     input.newpwd.focus();
    }
    else if(input.confirmpwd.value == '') {
       err[2]="Please enter confirm password";
       input.confirmpwd.focus();
    }
    else if(changepwdstrength(input) == false)
    {
      err[3]="Please enter password with minimum 6 characters";
      input.newpwd.focus();
    }
    else if(input.newpwd.value != input.confirmpwd.value)
    {
         err[4]="New password and Confirm password not matching";
       input.confirmpwd.focus();
    }
    
   //loop through errors 
    for(var i=0;i<err.length;i++)  {
    if(typeof err[i]!== 'undefined'){
      innerhtml += err[i] ;
      errcount = errcount + 1;
    }
    }
  
   //display errors
   if(errcount > 0) {
     var error = divtop + innerhtml + divbottom; 
     document.getElementById('valerror').style.display="none";
     document.getElementById('message').style.display="block";
     document.getElementById('message').innerHTML = error;
     return false;
   }
   else {
    return true;
   }
   
}

function changepwdstrength(input)
{
	var count = input.newpwd.value.length;
	if(count < 6)
	{
		return false;
	}
	else
	{
		return true;
	}
}

function user_validation(input)
{
  var err = new Array(14);	
  var errcount=0;
  var innerhtml='';
  var divtop='<p class="info">';
  var divbottom='</p><div class="blankmap"></div>';
  
  if(input.username.value == '')  {
	 err[0]="Please enter UserName.";
	 input.username.focus();
  }
  
  else if(input.password.value == '') {
	 err[1]="Please enter Password.";
	 input.password.focus();
  }
  else if(input.cnpassword.value == '') {
	 err[2]="Please enter Password.";
	 input.cnpassword.focus();
  }
  
  else if(input.fname.value == '') {
	 err[3]="Please enter your First Name.";
	 input.fname.focus();
  }
  
  else if(input.phone.value == '') {
	 err[4]="Please enter phone Number.";
	 input.phone.focus();
  }
  else if(input.email.value == '')
  {
	 err[5]="Please enter Email Address.";
	 input.email.focus();
  }
  else if(document.getElementById('SelectRight').options.length <= 0)
  {
	 err[6]="Please Select Role.";
	 input.SelectLeft.focus();
  }
  else if(input.level.value == 0)
  {
	 err[7]="Please Select User Level.";
	 input.level.focus();
  }
  else if(checkpassword(input) == false)
  {
    err[8]="Confirm Password not matching.";
	 input.cnpassword.focus();
  }
  else if(checkEmail(input) == false)
  {
    err[9]="Please enter valid Email address.";
	 input.email.focus();
  }
  
  else if(input.unameexist.value == 'User Name is not Available')
  {
    err[10]="Please enter available User Name.";
	 input.username.value = '';
	 input.username.focus();
  }
  else if(checkpwdstrength(input) == false)
  {
    err[11]="Please enter password with minimum 6 characters.";
    input.password.focus();
  }
  else if((input.dob.value !='') || (input.doj.value != ''))
  {
	  if((input.dob.value !='') && validate_date(input.dob.value) == false)
	  {
	     err[12]="Please enter valid Date of Birth.";
		 input.dob.focus();
	  }
	  
	  else if((input.doj.value != '') && validate_date(input.doj.value) == false)
	  {
			 err[13]="Please enter valid Date of Join.";
			 input.doj.focus();
	  }
	  else if((input.dob.value !='') && (input.doj.value != '')) 
	  {
		  if(CompareDates(input.dob.value,input.doj.value) == false)
		   {
				 err[14]="Date of birth can't be greater than date of join.";
				 input.dob.focus();
		   }
	  }
  }
  
  
 //loop through errors 
  for(var i=0;i<err.length;i++)  {
 	if(typeof err[i]!== 'undefined'){
		innerhtml += err[i] ;
	    errcount = errcount + 1;
	}
  }
 
 //display errors
 if(errcount > 0) {
	 var error = divtop + innerhtml + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 return false;
 }
 else {
  return true;
 }

}

function checkEmail(input) {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(input.email.value)){
	  var error = '';
	  document.getElementById('Messagebox').style.display="none";
	  document.getElementById('Messagebox').innerHTML = error;
	  return (true);
	}
	else{
	
	 var divtop='<p class="info">';
     var divbottom='</p><div class="blankmap"></div>';
     var error = divtop + 'Please enter valid Email address' + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 input.email.focus();
	 return (false);
	}
	
}

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && ((charCode < 48 || charCode > 57) && charCode != 32 && charCode != 45 && charCode != 43))
            return false;

         return true;
}

function isAlpha(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8 || charCode == 32)
            return true;

         return false;
      }
	  
	  
function checkpassword(input)
{
  var pwd = input.password.value;
  var repwd = input.cnpassword.value;
  
  if(pwd != repwd)
  {
     var divtop='<p class="info">';
     var divbottom='</p><div class="blankmap"></div>';
     var error = divtop + 'Confirm Password not matching' + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 input.cnpassword.focus();
	 return false;
  }
  else
  {
     var error = '';
	  document.getElementById('Messagebox').style.display="none";
	  document.getElementById('Messagebox').innerHTML = error;
	  return true;
  }
}	  

function checkpwdstrength(input)
{
  var count = input.password.value.length;
  if(count < 6)
  {
    return false;
  }
  else
  {
    return true;
  }
}

function isValidDate(sText) {
        //var reDate = /(?:0[1-9]|[12][0-9]|3[01])\-(?:0[1-9]|1[0-2])\-(?:19[0-9][0-9]|20\d{2})/;
      // var reDate = /(((0[1-9]|1[012])/(0[1-9]|1\d|2[0-8])|(0[13456789]|1[012])/(29|30)|(0[13578]|1[02])/31)/[2-9]\d{3}|02/29/(([2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))/;
       var reDate = /[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/(([1]{1}[9]{1}[9]{1}\d{1})|([2-9]{1}\d{3}))/;
        return reDate.test(sText);
 }
 function validate_date(val) {
        if (isValidDate(val)) {
			  return true;
        } else {
			 return false;
        }

 }
 
 
function CompareDates(str1,str2)
{
  var dt1  = parseInt(str1.substring(0,2),10);
  var mon1 = parseInt(str1.substring(3,5),10);
  var yr1  = parseInt(str1.substring(6,10),10);
  var dt2  = parseInt(str2.substring(0,2),10);
  var mon2 = parseInt(str2.substring(3,5),10);
  var yr2  = parseInt(str2.substring(6,10),10);
  var date1 = new Date(yr1, mon1-1, dt1);
  var date2 = new Date(yr2, mon2-1, dt2);
  if(date2 < date1)
  {
    return false;
  }
  else
  {
    return true;
  }
} 
 
 function isvalid_username(evt)
 {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode == 32)
       return false;
    else
    return true;
}

/* ==================================================================
  FUNCTION MANAGEMENT : VALIDATION SCRIPT
==================================================================== */

function function_validation(input)
{
  var innerhtml='';
  var divtop='<p class="info">';
  var divbottom='</p>';
  
  if(input.fnname.value == '')  {
	 innerhtml ="Please enter Function Name.";
	 var error = divtop + innerhtml + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 input.fnname.focus();
	 return false;
  }
 
 else {
  return true;
 }

}


/* ==================================================================
  RIGHTS MANAGEMENT : VALIDATION SCRIPT
==================================================================== */

function rights_validation(input)
{
  var innerhtml='';
  var divtop='<p class="info">';
  var divbottom='</p>';
  
  if(input.rightname.value == '')  {
	 innerhtml ="Please enter RightName.";
	 var error = divtop + innerhtml + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 input.rightname.focus();
	 return false;
  }
 
 else {
  return true;
 }

}


/* ==================================================================
  SUB FUNCTION MANAGEMENT : VALIDATION SCRIPT
==================================================================== */
function subfunction_validation(input)
{
  var err = new Array(2);	
  var errcount=0;
  var innerhtml='';
  var divtop='<p class="info">';
  var divbottom='</p>';
  
  if(input.fnname.value == '')  {
	 err[0]="Please select function.";
	 input.fnname.focus();
  }
  
  else if(input.subfnname.value == '') {
	 err[1]="Please enter Sub Function Name.";
	 input.subfnname.focus();
  }
  
 //loop through errors 
  for(var i=0;i<err.length;i++)  {
 	if(typeof err[i]!== 'undefined'){
		innerhtml += err[i] ;
	    errcount = errcount + 1;
	}
  }
 
 //display errors
 if(errcount > 0) {
	 var error = divtop + innerhtml + divbottom;
	 document.getElementById('Messagebox').style.display="block";
	 document.getElementById('Messagebox').innerHTML = error;
	 return false;
 }
 else {
  return true;
 }
 
 }
 
 
 /*===================================================================
 Role Validation
 =====================================================================*/
 
 function role_validation(input)
 {
	 var err = new Array(1);	 
	  var errcount=0;
	  var innerhtml='';
	  var divtop='<p class="info">';
	  var divbottom='</p>';
	  
	  if(input.rolename.value == '')  {
		 err[0]="Please enter Role Name.";
		 input.rolename.focus();
	  }
	  
	 //loop through errors 
	  for(var i=0;i<err.length;i++)  {
		if(typeof err[i]!== 'undefined'){
			innerhtml += err[i] ;
			errcount = errcount + 1;
		}
	  }
	 
	 //display errors
	 if(errcount > 0) {
		 var error = divtop + innerhtml + divbottom;
		 document.getElementById('Messagebox').style.display="block";
		 document.getElementById('Messagebox').innerHTML = error;
		 return false;
	 }
	 else {
	  return true;
	 }
 }
 
 /*===================================================================
   Report Validations
 ==================================================================== */
 
 function report_validation(input,type) 
 {
 // console.log(input);
  //console.log(type)
  //return false;
	  var err = new Array(5);	 
	  var errcount=0;
	  var innerhtml='';
	  var divtop='<p class="info">';
	  var divbottom='</p>';
	  if(type=='speedviolation' || type=='violation'){
            if(input.vehicle.value == '')  {
                   err[0]="Please select Vehicle Number.";
                  // input.vehicle.focus();
            }

            else if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                 //  input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                 //  input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                  // input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                 //  input.from.focus();
            }
         } else if(type=='availability'){
            /* if(input.vehicle.value == '')  {
                   err[0]="Please select Vehicle Number.";
                   input.vehicle.focus();
            } */
         }  else if(type=='analysis'){
            /* if(input.vehicle.value == '')  {
                   err[0]="Please select Vehicle Number.";
                   input.vehicle.focus();
            } */
         
         } else if(type=='NMMTInventory'){
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                 //  input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                 //  input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                 //  input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                 //  input.from.focus();
            }
             //return true;
         } 
         
            else if(type=='tripdistance'){
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                 //  input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                 //  input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                 //  input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                  // input.from.focus();
            }
             //return true;
         } else if(type=='MissedTravelledStoppagereport' || type=='exception' || type=='TripReport'){
          //change type name "tripdistancedetails" to "TripReport"
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                   // input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                   // input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                   //input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                  // input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                   //input.from.focus();
            }
             //return true;
         } else if(type=='TravelledStoppageDetails'){
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                   //input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                  // input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                  // input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                  // input.from.focus();
            }
             //return true;
         } else if( type == 'DailyOutSheddingReport' || type == 'ReserveVehicleAtDepotReport'){
             if(input.from.value == '') {
                   err[1]="Please enter Date.";
                   //input.from.focus();
            }
            
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid Date.";
                   //input.from.focus();
            }
            
         }
         else if(type=='TripSummaryReport' || type == 'OnTimePerformanceReport'){  //change type name "VehicleDistanceTravelled" to "TripSummaryReport"
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                  // input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                  // input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                  // input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                  // input.from.focus();
            }
             //return true;
         }else if(type=='WaitingPeriodOfBuses' || type=='Triptracking' || type=='DailyScheduleReport'){
          //alert($('#from').val());
        
             if(input.from.value == '') {
                   err[1]="Please enter StartDate.";
                   //input.from.focus();
            }
            else if(input.to.value == '') {
                   err[2]="Please enter EndDate.";
                   //input.to.focus();
            }
            else if(validate_date(input.from.value,type) == false)
            {
               err[3]="Please enter valid StartDate.";
                  // input.from.focus();
            }
            else if(validate_date(input.to.value,type) == false)
            {
               err[4]="Please enter valid EndDate.";
                   //input.to.focus();
            }
            else if(CompareDates(input.from.value,input.to.value) == false)
            {
               err[5]="Start date can't be greater than end date.";
                   //input.from.focus();
            }
             //return true;
             // alert("i am here");
         }
	  
	 //loop through errors 
	  for(var i=0;i<err.length;i++)  {
		if(typeof err[i]!== 'undefined'){
			innerhtml += err[i] ;
			errcount = errcount + 1;
		}
	  }
	 // alert(errcount);
	 //display errors
	 if(errcount > 0) {

		 var error = divtop + innerhtml + divbottom;
		 document.getElementById('Messagebox').style.visibility="visible";
		 document.getElementById('Messagebox').innerHTML = error;
		 return false;
	 }
	else {
    document.getElementById('Messagebox').style.visibility="hidden";
    return true;
  }
 }
 
 
 function violationsummeryreport_validation(input)
 {
	  var err = new Array(4);	 
	  var errcount=0;
	  var innerhtml='';
	  var divtop='<p class="info">';
	  var divbottom='</p>';
	  
	  if(input.from.value == '') {
		 err[0]="Please enter StartDate.";
		 input.from.focus();
	  }
	  else if(input.to.value == '') {
		 err[1]="Please enter EndDate.";
		 input.to.focus();
	  }
	  else if(validate_date(input.from.value) == false)
	  {
	     err[2]="Please enter valid StartDate.";
		 input.from.focus();
	  }
	  else if(validate_date(input.to.value) == false)
	  {
	     err[3]="Please enter valid EndDate.";
		 input.to.focus();
	  }
	   else if(CompareDates(input.from.value,input.to.value) == false)
	  {
	     err[4]="Start date can't be greater than end date.";
		 input.from.focus();
	  }
	  
	 //loop through errors 
	  for(var i=0;i<err.length;i++)  {
		if(typeof err[i]!== 'undefined'){
			innerhtml += err[i] ;
			errcount = errcount + 1;
		}
	  }
	 
	 //display errors
	 if(errcount > 0) {
		 var error = divtop + innerhtml + divbottom;
		 document.getElementById('Messagebox').style.display="block";
		 document.getElementById('Messagebox').innerHTML = error;
		 return false;
	 }
	 else {
	  return true;
	 }
 }
 
 
 function availabilityreport_validation(input)
 {
	  var err = new Array(3);	 
	  var errcount=0;
	  var innerhtml='';
	  var divtop='<p class="info">';
	  var divbottom='</p>';
	  
	  if(input.vehicle.value == '')  {
			 err[0]="Please select Vehicle Number.";
			 input.vehicle.focus();
		  }
	  else if(input.from.value == '') {
		 err[0]="Please enter StartDate.";
		 input.from.focus();
	  }
	  else if(validate_date(input.from.value) == false)
	  {
	     err[2]="Please enter valid StartDate.";
		 input.from.focus();
	  }
	  
	 //loop through errors 
	  for(var i=0;i<err.length;i++)  {
		if(typeof err[i]!== 'undefined'){
			innerhtml += err[i] ;
			errcount = errcount + 1;
		}
	  }
	 
	 //display errors
	 if(errcount > 0) {
		 var error = divtop + innerhtml + divbottom;
		 document.getElementById('Messagebox').style.display="block";
		 document.getElementById('Messagebox').innerHTML = error;
		 return false;
	 }
	 else {
	  return true;
	 }
 }
 
 /* ==================================================================
 TRIP MANAGEMENT : VALIDATION SCRIPT
==================================================================== */
function CompareTripDates(str1,str2)
{
    var dt1  = parseInt(str1.substring(0,2),10);
    var mon1 = parseInt(str1.substring(3,5),10);
    var yr1  = parseInt(str1.substring(6,10),10);
    var dt2  = parseInt(str2.substring(0,2),10);
    var mon2 = parseInt(str2.substring(3,5),10);
    var yr2  = parseInt(str2.substring(6,10),10);
    var date1 = new Date(yr1, mon1, dt1);
    var date2 = new Date(yr2, mon2, dt2);
    if(date2  >  date1)
    {
        return 2;
    }
	else if(date2  < date1)
    {
        return 0;
    }
    else
    {
        return 1;
    }
} 

 function trip_assign_validate(input)
 {
 	  document.getElementById('Messagebox').innerHTML = '';
 	  var err = new Array(11);	 
 	  var errcount=0;
 	  var innerhtml='';
 	  var divtop='<p class="info">';
 	  var divbottom='</p>';

 	  if(input.service.value == '') {
 		 err[0]="Please select a service.";
 		 input.service.focus();
 	  }
 	 else if(input.vehicle_no.value == ''){
		  err[1]="Please enter vehicle number.";
		  input.vehicle_no.focus();
	  }
 	  else if(input.dep_date.value == ''){
 		  err[2]="Please enter departure date.";
 		  input.dep_date.focus();
 	  }
 	 else if(input.dep_time_hour.value == ''){
		  err[3]="Please select departure hour.";
		  input.dep_time_hour.focus();
	  }
	  else if(input.dep_time_min.value == ''){
		  err[4]="Please select departure minutes.";
		  input.dep_time_min.focus();
	  }
 	 else if(input.arrival_date.value == ''){
		  err[5]="Please enter arrival date.";
		  input.dep_date.focus();
	  }
	  else if(input.arrival_time_hour.value == ''){
		  err[6]="Please select arrival hour.";
		  input.dep_time_hour.focus();
	  }
	  else if(input.arrival_time_min.value == ''){
		  err[7]="Please select arrival minutes.";
		  input.dep_time_min.focus();
	  }
	  else if(input.dep_date.value != '' && input.arrival_date.value != '')
	  {
		  if(CompareTripDates(input.dep_date.value,input.arrival_date.value) == 0)
		   {
				 err[8]="Departure date can't be greater than Arrival date.";
				 input.arrival_date.focus();
		   }
		  else if(CompareTripDates(input.dep_date.value,input.arrival_date.value) == 1)
		  {
				  if(input.arrival_time_hour.value < input.dep_time_hour.value )
					{
						err[9]="Departure time can't be greater than Arrival time.";
						input.arrival_time_hour.focus();
					}
				  else if(input.arrival_time_hour.value == input.dep_time_hour.value)
					 {
					   if(input.arrival_time_min.value < input.dep_time_min.value)
						   {
							 err[10]="Departure time can't be greater than Arrival time.";
							 input.arrival_time_hour.focus();
						   }
					 }
		  }
		   
	  }
 	  
 	 //loop through errors 
 	  for(var i=0;i<err.length;i++)  {
 		if(typeof err[i]!== 'undefined'){
 			innerhtml += err[i] ;
 			errcount = errcount + 1;
 		}
 	  }
 	 
 	 //display errors
 	 if(errcount > 0) {
 		 var error = divtop + innerhtml + divbottom;
 		 document.getElementById('Messagebox').style.display="block";
 		 document.getElementById('Messagebox').innerHTML = error;
		 if(document.getElementById('actionstatus')) {
			document.getElementById('actionstatus').style.display="none"; 
		 }
 		 return false;
 	 }
 	 else {
 	  return true;
 	 }
 }

function edituser_validation(input)
{
	var err = new Array(15);	
	var errcount=0;
	var innerhtml='';
	var divtop='<p class="info">';
	var divbottom='</p><div class="blankmap"></div>';

	if(input.username.value == '')  {
		err[0]="Please enter UserName";
		input.username.focus();
	}
	
	else if(input.cpwd.checked)
    {
		if(input.password.value == '') {
			err[1]="Please enter Password";
			input.password.focus();
		}
		else if(input.cnpassword.value == '') {
			err[2]="Please enter Password";
			input.cnpassword.focus();
		}
		else if(checkpwdstrength(input) == false)
		{
			err[3]="Please enter password with minimum 6 characters";
			input.password.focus();
		}
		else if(input.password.value != input.cnpassword.value)
		{
			     err[3]="New password and Confirm password not matching";
				 input.cnpassword.focus();
		}
    }
	
	else if(input.fname.value == '') {
		err[4]="Please enter your First Name";
		input.fname.focus();
	}

	else if(input.phone.value == '') {
		err[5]="Please enter phone Number";
		input.phone.focus();
	}
	else if(input.email.value == '')
	{
		err[6]="Please enter Email Address";
		input.email.focus();
	}
	else if(document.getElementById('SelectRight').options.length <= 0)
	{
		err[7]="Please Select Role";
		input.SelectLeft.focus();
	}
	else if(input.level.value == 0)
	{
		err[8]="Please Select User Level";
		input.level.focus();
	}
	else if(checkpassword(input) == false)
	{
		err[9]="New password and Confirm password not matching";
		input.cnpassword.focus();
	}
	else if(checkEmail(input) == false)
	{
		err[10]="Please enter valid Email address";
		input.email.focus();
	}

	else if(input.unameexist.value == 'User Name is not Available')
	{
		err[11]="Please enter available User Name";
		input.username.value = '';
		input.username.focus();
	}
	else if(input.level.value !=1 && input.level.value !=0)
	{
		  if(input.level.value == 2)
		  {
			  if(input.region.value == 0)
			  {
				  err[15]="Please select region";
				  input.region.focus();
			  }
		  }
		  else if(input.level.value == 3)
		  {
			  if(input.region.value == 0)
			  {
				  err[15]="Please select region";
				  input.region.focus();
			  }
			  else if(input.area.value == 0)
			  {
				  err[15]="Please select area";
				  input.area.focus();
			  }
		  }
		  else if(input.level.value == 4)
		  {
			  if(input.region.value == 0)
			  {
				  err[15]="Please select region";
				  input.region.focus();
			  }
			  else if(input.area.value == 0)
			  {
				  err[15]="Please select area";
				  input.area.focus();
			  }
			  else if(input.tertry.value == 0)
			  {
				  err[15]="Please select territory";
				  input.tertry.focus();
			  }
		  }
		  else if(input.level.value == 5)
		  {
			  if(input.region.value == 0)
			  {
				  err[15]="Please select region";
				  input.region.focus();
			  }
			  else if(input.area.value == 0)
			  {
				  err[15]="Please select area";
				  input.area.focus();
			  }
			  else if(input.tertry.value == 0)
			  {
				  err[15]="Please select territory";
				  input.tertry.focus();
			  }
			  else if(input.depot.value == 0)
			  {
				  err[15]="Please select depot";
				  input.depot.focus();
			  }
		  }
		  else if(input.level.value == 6)
		  {
			  if(input.region.value == 0)
			  {
				  err[15]="Please select region";
				  input.region.focus();
			  }
			  else if(input.area.value == 0)
			  {
				  err[15]="Please select area";
				  input.area.focus();
			  }
			  else if(input.tertry.value == 0)
			  {
				  err[15]="Please select territory";
				  input.tertry.focus();
			  }
			  else if(input.depot.value == 0)
			  {
				  err[15]="Please select depot";
				  input.depot.focus();
			  }
			  else if(input.base.value == 0)
			  {
				  err[15]="Please select Retailoutlet/Transporter";
				  input.base.focus();
			  }
		  }
	}
	
	else if((input.dob.value !='') || (input.doj.value != ''))
	{
		if((input.dob.value !='') && validate_date(input.dob.value) == false)
		{
			err[12]="Please enter valid Date of Birth";
			input.dob.focus();
		}

		else if((input.doj.value != '') && validate_date(input.doj.value) == false)
		{
			err[13]="Please enter valid Date of Join";
			input.doj.focus();
		}
		else if((input.dob.value !='') && (input.doj.value != '')) 
		{
			if(CompareDates(input.dob.value,input.doj.value) == false)
			{
				err[14]="Date of birth cannot be greater than date of join";
				input.dob.focus();
			}
		}
	}
	
	

	//loop through errors 
	for(var i=0;i<err.length;i++)  { 
		if(typeof err[i]!== 'undefined'){
			innerhtml += err[i] ;
			errcount = errcount + 1;
		}
	} 

	//display errors
	if(errcount > 0) {
		var error = divtop + innerhtml + divbottom;
		document.getElementById('Messagebox').style.display="block";
		document.getElementById('Messagebox').innerHTML = error;
		return false;
	}
	else {
		return true;
	}

}
