// JavaScript Document
jQuery(document).ready(function($) {
	jQuery('#Popup').live('click', function(){
		newwindow=window.open($(this).attr('href'),'','height=800,width=800');
		if (window.focus) {newwindow.focus()}
		return false;
	});
});