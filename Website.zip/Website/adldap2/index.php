<?php
# Includes the autoloader for libraries installed with composer
require __DIR__ . '/vendor/autoload.php';
// Construct new Adldap instance.
$ad = new \Adldap\Adldap();

// Create a configuration array.
$config = [
  // Your account suffix, for example: jdoe@corp.acme.org
  'account_suffix'        => '@Corp.FC.LOCAL',
  
  // The domain controllers option is an array of your LDAP hosts. You can
  // use the either the host name or the IP address of your host.
  'domain_controllers'    => ['10.159.166.12'],
  
  // The base distinguished name of your domain.
  'base_dn'               => 'dc=corp,dc=FC,dc=LOCAL',
  
  // The account to use for querying / modifying LDAP records. This
  // does not need to be an actual admin account.
  'admin_username'        => 'svcrobot29',
  'admin_password'        => '5EcuNuzE5EcuNuzE',
];

// Add a connection provider to Adldap.
$ad->addProvider($config);

try {
    // If a successful connection is made to your server, the provider will be returned.
    $provider = $ad->connect();

    // Performing a query.
    $results = $provider->search()->where('cn', '=', 'svcrobot29')->get();
    
    // Finding a record.
    $user = $provider->search()->find('svcrobot29');
var_dump( $user);
     

    // Saving the changes to your LDAP server.
   /* if ($user->save()) {
        // User was saved!
    }*/
} catch (\Adldap\Auth\BindException $e) {

echo $e;
    // There was an issue binding / connecting to the server.

}

?>